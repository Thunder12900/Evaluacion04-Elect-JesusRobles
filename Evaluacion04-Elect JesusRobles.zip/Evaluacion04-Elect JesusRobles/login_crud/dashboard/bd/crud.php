<?php
include_once '../bd/conexion.php';
$objeto = new Conexion();
$conexion = $objeto->Conectar();
// Recepción de los datos enviados mediante POST desde el JS   

$nombre = (isset($_POST['nombre'])) ? $_POST['nombre'] : '';
$cedula = (isset($_POST['cedula'])) ? $_POST['cedula'] : '';
$edad = (isset($_POST['edad'])) ? $_POST['edad'] : '';
$producto = (isset($_POST['producto'])) ? $_POST['producto'] : '';
$opcion = (isset($_POST['opcion'])) ? $_POST['opcion'] : '';
$id = (isset($_POST['id'])) ? $_POST['id'] : '';

$descripcion = (isset($_POST['descripcion'])) ? $_POST['descripcion'] : '';
$precio = (isset($_POST['precio'])) ? $_POST['precio'] : '';
$stock = (isset($_POST['stock'])) ? $_POST['stock'] : '';
$opcion = (isset($_POST['opcion'])) ? $_POST['opcion'] : '';
$id = (isset($_POST['id'])) ? $_POST['id'] : '';

switch($opcion){
    case 1: //alta
        $consulta = "INSERT INTO personas (nombre, cedula, edad, producto) VALUES('$nombre', '$cedula', '$edad', '$producto') ";
        $consulta = "INSERT INTO ventas (descripcion, precio, stock) VALUES('$descripcion', '$precio', '$stock') ";						
        $resultado = $conexion->prepare($consulta);
        $resultado->execute(); 

        $consulta = "SELECT id, nombre, cedula, edad, producto FROM personas ORDER BY id DESC LIMIT 1";
        $consulta = "SELECT id,descripcion, precio, stock FROM ventas ORDER BY id DESC LIMIT 1";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break;
    case 2: //modificación
        $consulta = "UPDATE personas SET nombre='$nombre', cedula='$cedula', edad='$edad', producto='$producto' WHERE id='$id' ";
        $consulta = "UPDATE ventas SET descripcion='$descripcion', precio='$precio', stock='$stock' WHERE id='$id' ";				
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();        
        
        $consulta = "SELECT id, nombre, cedula, edad, producto FROM personas WHERE id='$id' ";
        $consulta = "SELECT id, descripcion, precio, stock FROM ventas WHERE id='$id' ";       
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break;        
    case 3://baja
        $consulta = "DELETE FROM personas WHERE id='$id' ";
        $consulta = "DELETE FROM ventas WHERE id='$id' ";		
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();                           
        break;        
}

print json_encode($data, JSON_UNESCAPED_UNICODE); //enviar el array final en formato json a JS
$conexion = NULL;
